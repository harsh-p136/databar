package com.databar.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.DateFormat
import java.util.Date

class MainActivity : Activity() {

    private val BG = Color.parseColor("#EEF1F7")
    private val INK = Color.parseColor("#0F1B33")
    private val MUTED = Color.parseColor("#596583")
    private val ACCENT = Color.parseColor("#2446E8")
    private val WARN = Color.parseColor("#B25E00")
    private val LINE = Color.parseColor("#D6DCEA")

    private val handler = Handler(Looper.getMainLooper())
    private val refresher = object : Runnable {
        override fun run() {
            refreshHome()
            handler.postDelayed(this, 15_000L)
        }
    }

    private lateinit var home: ScrollView
    private lateinit var settings: ScrollView
    private lateinit var gear: ImageView

    private lateinit var bigNum: TextView
    private lateinit var bigLabel: TextView
    private lateinit var bar: ProgressBar
    private lateinit var statUsed: TextView
    private lateinit var statLimit: TextView
    private lateinit var statReserve: TextView
    private lateinit var statPlan: TextView
    private lateinit var banner: TextView
    private lateinit var permBtn: Button

    private lateinit var search: EditText
    private lateinit var results: LinearLayout
    private lateinit var fPrice: EditText
    private lateinit var fGb: EditText
    private lateinit var fDays: EditText
    private lateinit var fReserve: EditText
    private lateinit var simBox: LinearLayout

    private var showingSettings = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG)
            fitsSystemWindows = true
        }
        root.addView(buildHeader())
        val frame = FrameLayout(this)
        home = buildHome()
        settings = buildSettings()
        settings.visibility = View.GONE
        frame.addView(home)
        frame.addView(settings)
        root.addView(frame, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        fillSettings()
    }

    override fun onResume() {
        super.onResume()
        if (Usage.hasAccess(this)) {
            try { UsageService.start(this) } catch (e: Exception) {}
        }
        handler.post(refresher)
    }

    override fun onPause() {
        handler.removeCallbacks(refresher)
        super.onPause()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 2) renderSims()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (showingSettings) toggleSettings() else super.onBackPressed()
    }

    // ---------- header ----------
    private fun buildHeader(): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(14), dp(20), dp(6))
        }
        val logo = ImageView(this).apply { setImageResource(R.drawable.ic_ring) }
        row.addView(logo, LinearLayout.LayoutParams(dp(28), dp(28)))
        val title = TextView(this).apply {
            text = "Databar"
            setTextColor(INK)
            textSize = 24f
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            setPadding(dp(10), 0, 0, 0)
        }
        row.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        gear = ImageView(this).apply {
            setImageResource(R.drawable.ic_gear)
            scaleType = ImageView.ScaleType.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.WHITE)
                setStroke(dp(1), LINE)
            }
            contentDescription = "Settings and plan"
            setOnClickListener { toggleSettings() }
        }
        row.addView(gear, LinearLayout.LayoutParams(dp(42), dp(42)))
        return row
    }

    private fun toggleSettings() {
        showingSettings = !showingSettings
        home.visibility = if (showingSettings) View.GONE else View.VISIBLE
        settings.visibility = if (showingSettings) View.VISIBLE else View.GONE
        gear.contentDescription = if (showingSettings) "Back to usage" else "Settings and plan"
        (gear.background as GradientDrawable).setColor(if (showingSettings) Color.parseColor("#E4E9FD") else Color.WHITE)
        if (!showingSettings) refreshHome()
    }

    // ---------- helpers ----------
    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(16), dp(16), dp(16))
        background = GradientDrawable().apply {
            cornerRadius = dp(16).toFloat()
            setColor(Color.WHITE)
            setStroke(dp(1), LINE)
        }
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) }
    }

    private fun label(t: String): TextView = TextView(this).apply {
        text = t
        setTextColor(MUTED)
        textSize = 12f
        letterSpacing = 0.08f
        typeface = Typeface.DEFAULT_BOLD
        setPadding(0, 0, 0, dp(8))
    }

    private fun body(t: String = ""): TextView = TextView(this).apply {
        text = t
        setTextColor(INK)
        textSize = 15f
    }

    private fun primaryButton(t: String, onClick: () -> Unit): Button = Button(this).apply {
        text = t
        isAllCaps = false
        setTextColor(Color.WHITE)
        typeface = Typeface.DEFAULT_BOLD
        background = GradientDrawable().apply { cornerRadius = dp(10).toFloat(); setColor(ACCENT) }
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(8) }
    }

    private fun softButton(t: String, onClick: () -> Unit): Button = Button(this).apply {
        text = t
        isAllCaps = false
        setTextColor(ACCENT)
        typeface = Typeface.DEFAULT_BOLD
        background = GradientDrawable().apply { cornerRadius = dp(10).toFloat(); setColor(Color.parseColor("#E4E9FD")) }
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(8) }
    }

    private fun input(hint: String, type: Int): EditText = EditText(this).apply {
        this.hint = hint
        inputType = type
        setTextColor(INK)
        textSize = 15f
        setPadding(dp(12), 0, dp(12), 0)
        background = GradientDrawable().apply {
            cornerRadius = dp(10).toFloat()
            setColor(BG)
            setStroke(dp(1), LINE)
        }
        layoutParams = LinearLayout.LayoutParams(-1, dp(46)).apply { bottomMargin = dp(8) }
    }

    private fun fieldLabel(t: String) = TextView(this).apply {
        text = t
        setTextColor(INK)
        textSize = 13f
        typeface = Typeface.DEFAULT_BOLD
        setPadding(0, dp(4), 0, dp(4))
    }

    private fun pad(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(8), dp(16), dp(32))
    }

    // ---------- home ----------
    private fun buildHome(): ScrollView {
        val col = pad()

        banner = TextView(this).apply {
            textSize = 15f
            setTextColor(INK)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(14), dp(12), dp(14), dp(12))
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) }
        }
        col.addView(banner)

        val c1 = card()
        c1.addView(label("DATA YOU CAN USE TODAY"))
        bigNum = TextView(this).apply {
            setTextColor(INK)
            textSize = 52f
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        }
        c1.addView(bigNum)
        bigLabel = body().apply { setTextColor(MUTED); textSize = 14f }
        c1.addView(bigLabel)
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            progressTintList = android.content.res.ColorStateList.valueOf(ACCENT)
            layoutParams = LinearLayout.LayoutParams(-1, dp(14)).apply { topMargin = dp(14); bottomMargin = dp(14) }
        }
        c1.addView(bar)
        statUsed = body()
        statLimit = body()
        statReserve = body()
        statPlan = body()
        listOf(statUsed, statLimit, statReserve, statPlan).forEach {
            it.setPadding(0, dp(2), 0, dp(2))
            c1.addView(it)
        }
        col.addView(c1)

        permBtn = primaryButton("Allow usage access") {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        }
        col.addView(permBtn)

        // Fetch section stays at the very bottom.
        val c2 = card()
        (c2.layoutParams as LinearLayout.LayoutParams).topMargin = dp(24)
        c2.addView(label("CHECK WITH JIO"))
        c2.addView(body("Databar reads your phone's mobile data meter. Jio may count a little differently, so compare once in MyJio.").apply {
            setTextColor(MUTED); textSize = 13f
        })
        c2.addView(softButton("Refresh now") { refreshHome(); Toast.makeText(this, "Updated", Toast.LENGTH_SHORT).show() })
        c2.addView(softButton("Open MyJio") { openMyJio() })
        col.addView(c2)

        return ScrollView(this).apply { addView(col) }
    }

    private fun openMyJio() {
        val i = packageManager.getLaunchIntentForPackage("com.jio.myjio")
        if (i != null) startActivity(i)
        else startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.jio.com")))
    }

    private fun refreshHome() {
        val limit = Store.perDayMb(this)
        val reserve = Store.reserveMb(this).coerceIn(0, limit - 1)
        val alertAt = limit - reserve
        val hasAccess = Usage.hasAccess(this)
        permBtn.visibility = if (hasAccess) View.GONE else View.VISIBLE

        statLimit.text = "Daily quota: ${Usage.fmt(limit.toLong())}"
        statReserve.text = "Night reserve: ${Usage.fmt(reserve.toLong())}"
        val exp = Store.expiry(this)
        statPlan.text = if (exp > 0) {
            val days = Math.max(0L, (exp - System.currentTimeMillis()) / 86_400_000L)
            "Plan ends: ${DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(exp))} ($days days left)"
        } else "Plan ends: not set. Open settings."

        if (!hasAccess) {
            setBanner("Usage access needed", "#FBEED9")
            bigNum.text = "--"
            bigLabel.text = "Allow usage access so Databar can read your mobile data"
            bar.max = 100; bar.progress = 0
            statUsed.text = "Used today: unknown"
            return
        }
        val used = Usage.todayMb(this)
        if (used < 0) {
            setBanner("Could not read mobile data", "#FBE4DF")
            bigNum.text = "--"; bigLabel.text = ""
            statUsed.text = "Used today: unknown"
            return
        }
        statUsed.text = "Used today: ${Usage.fmt(used)}"
        bar.max = limit
        bar.progress = used.toInt().coerceAtMost(limit)
        when {
            used >= limit -> { setBanner("Daily data finished", "#FBE4DF"); bigNum.text = "0 MB"; bigLabel.text = "Speed drops until midnight" }
            used >= alertAt -> { setBanner("Reserve zone", "#FBEED9"); bigNum.text = Usage.fmt(limit - used); bigLabel.text = "reserve left, keep it for tonight" }
            else -> { setBanner("On track", "#E3F4EC"); bigNum.text = Usage.fmt(alertAt - used); bigLabel.text = "usable before your reserve" }
        }
    }

    private fun setBanner(t: String, color: String) {
        banner.text = t
        banner.background = GradientDrawable().apply { cornerRadius = dp(14).toFloat(); setColor(Color.parseColor(color)) }
    }

    // ---------- settings ----------
    private fun buildSettings(): ScrollView {
        val col = pad()

        val cs = card()
        cs.addView(label("SIM"))
        simBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        cs.addView(simBox)
        cs.addView(body("Android gives apps one combined mobile data meter. Databar counts data only while the SIM you choose is the one set for mobile data.").apply {
            setTextColor(MUTED); textSize = 13f; setPadding(0, dp(8), 0, 0)
        })
        col.addView(cs)

        val c1 = card()
        c1.addView(label("FIND YOUR PLAN"))
        search = input("Search by price, data or days (try 299, 1.5, 84)", InputType.TYPE_CLASS_TEXT)
        c1.addView(search)
        results = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        c1.addView(results)
        c1.addView(body("Daily data is not fixed at 1.5 GB. Pick a plan or type your own numbers below. Check plans in MyJio.").apply {
            setTextColor(MUTED); textSize = 13f; setPadding(0, dp(8), 0, 0)
        })
        col.addView(c1)

        val c2 = card()
        c2.addView(label("PLAN DETAILS"))
        c2.addView(fieldLabel("Recharge price (₹)"))
        fPrice = input("e.g. 299", InputType.TYPE_CLASS_NUMBER)
        c2.addView(fPrice)
        c2.addView(fieldLabel("Data per day (GB)"))
        fGb = input("e.g. 1.5", InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL)
        c2.addView(fGb)
        c2.addView(fieldLabel("Validity (days, counted from today)"))
        fDays = input("e.g. 28", InputType.TYPE_CLASS_NUMBER)
        c2.addView(fDays)
        c2.addView(fieldLabel("Night reserve (MB)"))
        fReserve = input("e.g. 200", InputType.TYPE_CLASS_NUMBER)
        c2.addView(fReserve)
        c2.addView(primaryButton("Save plan") { savePlan() })
        col.addView(c2)

        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { renderResults() }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        renderResults()
        renderSims()
        return ScrollView(this).apply { addView(col) }
    }

    private fun renderSims() {
        simBox.removeAllViews()
        if (!Sims.hasPermission(this)) {
            simBox.addView(body("Allow phone access so Databar can list your SIMs.").apply { setTextColor(MUTED) })
            simBox.addView(primaryButton("Allow SIM access") {
                requestPermissions(arrayOf(Manifest.permission.READ_PHONE_STATE), 2)
            })
            return
        }
        val sims = Sims.list(this)
        if (!Store.simChosen(this)) {
            sims.firstOrNull { it.name.contains("jio", ignoreCase = true) }?.let { Store.saveSim(this, it.id) }
        }
        val chosen = Store.simId(this)
        fun option(text: String, id: Int) {
            val on = chosen == id && Store.simChosen(this) || (id == -1 && !Store.simChosen(this))
            simBox.addView(Button(this).apply {
                this.text = (if (on) "●  " else "○  ") + text
                isAllCaps = false
                gravity = Gravity.START or Gravity.CENTER_VERTICAL
                setTextColor(INK)
                background = GradientDrawable().apply {
                    cornerRadius = dp(12).toFloat()
                    setColor(if (on) Color.parseColor("#E4E9FD") else BG)
                    setStroke(dp(1), if (on) ACCENT else LINE)
                }
                setPadding(dp(14), 0, dp(14), 0)
                layoutParams = LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(6) }
                setOnClickListener {
                    Store.saveSim(this@MainActivity, id)
                    renderSims()
                    refreshHome()
                }
            })
        }
        sims.forEach { option(it.name, it.id) }
        option("Any SIM (count all mobile data)", -1)
    }

    private fun renderResults() {
        results.removeAllViews()
        val list = Plans.search(search.text.toString())
        if (list.isEmpty()) {
            results.addView(body("No plan like that. Type your own numbers below.").apply { setTextColor(MUTED) })
            return
        }
        list.forEach { p ->
            val b = Button(this).apply {
                text = "₹${p.price}   ·   ${p.gb} GB/day   ·   ${p.label}"
                isAllCaps = false
                gravity = Gravity.START or Gravity.CENTER_VERTICAL
                setTextColor(INK)
                background = GradientDrawable().apply {
                    cornerRadius = dp(12).toFloat(); setColor(BG); setStroke(dp(1), LINE)
                }
                setPadding(dp(14), 0, dp(14), 0)
                layoutParams = LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(6) }
                setOnClickListener {
                    fPrice.setText(p.price.toString())
                    fGb.setText(p.gb.toString())
                    fDays.setText(p.days.toString())
                    Toast.makeText(this@MainActivity, "Filled. Tap Save plan.", Toast.LENGTH_SHORT).show()
                }
            }
            results.addView(b)
        }
    }

    private fun fillSettings() {
        val limit = Store.perDayMb(this)
        fPrice.setText(if (Store.price(this) > 0) Store.price(this).toString() else "")
        fGb.setText((limit / 1024.0).toString().removeSuffix(".0"))
        fReserve.setText(Store.reserveMb(this).toString())
        val exp = Store.expiry(this)
        if (exp > 0) {
            val d = ((exp - System.currentTimeMillis()) / 86_400_000L + 1).coerceAtLeast(1)
            fDays.setText(d.toString())
        }
    }

    private fun savePlan() {
        val gb = fGb.text.toString().toDoubleOrNull()
        val days = fDays.text.toString().toIntOrNull()
        val reserve = fReserve.text.toString().toIntOrNull() ?: 200
        val price = fPrice.text.toString().toIntOrNull() ?: 0
        if (gb == null || gb <= 0) { toast("Enter data per day, for example 1.5"); return }
        if (days == null || days < 1) { toast("Enter the validity in days"); return }
        if (reserve < 0 || reserve >= gb * 1024) { toast("Reserve must be smaller than the daily data"); return }
        Store.savePlan(this, price, gb, days, reserve)
        toast("Plan saved")
        if (Usage.hasAccess(this)) { try { UsageService.start(this) } catch (e: Exception) {} }
        toggleSettings()
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()
}
