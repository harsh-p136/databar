package com.databar.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper

class UsageService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            update()
            handler.postDelayed(this, 60_000L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CH_LIVE, "Live data usage", NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_ALERT, "Data alerts", NotificationManager.IMPORTANCE_HIGH)
        )
        val first = buildLive("Databar", "Reading your data usage...", 0, 0)
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(ID_LIVE, first, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(ID_LIVE, first)
        }
        handler.post(tick)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        handler.removeCallbacks(tick)
        handler.post(tick)
        return START_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun update() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (!Usage.hasAccess(this)) {
            nm.notify(ID_LIVE, buildLive("Databar needs permission", "Tap to allow usage access", 0, 0))
            return
        }
        val used = Usage.todayMb(this)
        if (used < 0) {
            nm.notify(ID_LIVE, buildLive("Databar", "Could not read mobile data right now", 0, 0))
            return
        }
        val limit = Store.perDayMb(this)
        val reserve = Store.reserveMb(this).coerceIn(0, limit - 1)
        val alertAt = limit - reserve

        val title = "Used ${Usage.fmt(used)} of ${Usage.fmt(limit.toLong())}"
        val text = when {
            used >= limit -> "Daily data finished. Speed drops until midnight."
            used >= alertAt -> "Reserve zone: ${Usage.fmt(limit - used)} left for tonight"
            else -> "${Usage.fmt(alertAt - used)} usable before your ${Usage.fmt(reserve.toLong())} reserve"
        }
        nm.notify(ID_LIVE, buildLive(title, text, limit, used.toInt().coerceAtMost(limit)))

        val today = Usage.dayKey()
        if (used >= limit && Store.lastFinishDay(this) != today) {
            Store.markFinish(this, today)
            Store.markAlert(this, today)
            alert(nm, "Daily data finished", "You used all of ${Usage.fmt(limit.toLong())} today.")
        } else if (used >= alertAt && Store.lastAlertDay(this) != today) {
            Store.markAlert(this, today)
            alert(nm, "Data alert", "You reached ${Usage.fmt(alertAt.toLong())}. Only ${Usage.fmt(reserve.toLong())} is left for tonight.")
        }
    }

    private fun alert(nm: NotificationManager, title: String, text: String) {
        val n = Notification.Builder(this, CH_ALERT)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(title)
            .setContentText(text)
            .setAutoCancel(true)
            .setContentIntent(openApp())
            .build()
        nm.notify(ID_ALERT, n)
    }

    private fun buildLive(title: String, text: String, max: Int, progress: Int): Notification {
        val b = Notification.Builder(this, CH_LIVE)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(title)
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setContentIntent(openApp())
        if (max > 0) b.setProgress(max, progress, false)
        return b.build()
    }

    private fun openApp(): PendingIntent {
        val i = Intent(this, MainActivity::class.java)
        return PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    companion object {
        const val CH_LIVE = "live"
        const val CH_ALERT = "alert"
        const val ID_LIVE = 1
        const val ID_ALERT = 2

        fun start(c: Context) {
            c.startForegroundService(Intent(c, UsageService::class.java))
        }
    }
}
