package com.databar.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED && Usage.hasAccess(context)) {
            try {
                UsageService.start(context)
            } catch (e: Exception) {
            }
        }
    }
}
