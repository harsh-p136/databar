package com.databar.app

import android.app.AppOpsManager
import android.Manifest
import android.app.usage.NetworkStatsManager
import android.content.Context
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.os.Process
import android.telephony.SubscriptionManager
import java.util.Calendar

data class Plan(val price: Int, val days: Int, val gb: Double, val label: String)

object Plans {
    val all = listOf(
        Plan(199, 18, 1.5, "18 days"),
        Plan(239, 22, 1.5, "22 days"),
        Plan(299, 28, 1.5, "28 days"),
        Plan(319, 30, 1.5, "1 month"),
        Plan(329, 28, 1.5, "28 days"),
        Plan(339, 30, 1.5, "1 month"),
        Plan(495, 28, 1.5, "28 days, +5 GB extra"),
        Plan(579, 56, 1.5, "56 days"),
        Plan(666, 70, 1.5, "70 days"),
        Plan(799, 84, 1.5, "84 days"),
        Plan(889, 84, 1.5, "84 days"),
        Plan(3599, 365, 2.5, "365 days")
    )

    fun search(query: String): List<Plan> {
        val tokens = query.lowercase()
            .replace("₹", " ").replace("rs.", " ").replace("rs", " ")
            .replace("/day", " ").replace("days", " ").replace("day", " ").replace("gb", " ")
            .trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (tokens.isEmpty()) return all
        return all.filter { p ->
            tokens.all { t ->
                p.price.toString().startsWith(t) ||
                    p.gb.toString() == t || p.gb.toString() == "$t.0" ||
                    p.days.toString() == t ||
                    p.label.lowercase().contains(t)
            }
        }
    }
}

object Store {
    fun prefs(c: Context) = c.getSharedPreferences("databar", Context.MODE_PRIVATE)

    fun perDayMb(c: Context): Int = prefs(c).getInt("perDayMb", 1536)
    fun reserveMb(c: Context): Int = prefs(c).getInt("reserveMb", 200)
    fun price(c: Context): Int = prefs(c).getInt("price", 0)
    fun expiry(c: Context): Long = prefs(c).getLong("expiry", 0L)
    fun lastAlertDay(c: Context): String = prefs(c).getString("alertDay", "") ?: ""
    fun lastFinishDay(c: Context): String = prefs(c).getString("finishDay", "") ?: ""

    fun savePlan(c: Context, price: Int, gb: Double, days: Int, reserveMb: Int) {
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, days - 1)
        cal.set(Calendar.HOUR_OF_DAY, 23)
        cal.set(Calendar.MINUTE, 59)
        cal.set(Calendar.SECOND, 0)
        prefs(c).edit()
            .putInt("price", price)
            .putInt("perDayMb", Math.round(gb * 1024).toInt())
            .putInt("reserveMb", reserveMb)
            .putLong("expiry", cal.timeInMillis)
            .apply()
    }

    /** -1 means count all mobile data, otherwise the chosen SIM's subscription id. */
    fun simId(c: Context): Int = prefs(c).getInt("simId", -1)
    fun simChosen(c: Context): Boolean = prefs(c).getBoolean("simChosen", false)
    fun saveSim(c: Context, id: Int) {
        prefs(c).edit().putInt("simId", id).putBoolean("simChosen", true)
            .putLong("last", 0L).putLong("attr", 0L).putString("attrDay", "").apply()
    }

    fun markAlert(c: Context, day: String) = prefs(c).edit().putString("alertDay", day).apply()
    fun markFinish(c: Context, day: String) = prefs(c).edit().putString("finishDay", day).apply()
}

object Usage {
    fun hasAccess(c: Context): Boolean {
        val ops = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = ops.unsafeCheckOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName
        )
        return mode == AppOpsManager.MODE_ALLOWED
    }

    /** All mobile data bytes since midnight (every SIM together). Returns -1 when it cannot be read. */
    private fun rawTodayBytes(c: Context): Long {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        return try {
            val nsm = c.getSystemService(Context.NETWORK_STATS_SERVICE) as NetworkStatsManager
            val b = nsm.querySummaryForDevice(
                ConnectivityManager.TYPE_MOBILE, null, cal.timeInMillis, System.currentTimeMillis()
            )
            b.rxBytes + b.txBytes
        } catch (e: Exception) {
            -1L
        }
    }

    /**
     * Mobile data used today in MB for the chosen SIM. Android does not give apps a per-SIM meter,
     * so new usage is added to the total only while the chosen SIM is the one set for mobile data.
     */
    @Synchronized
    fun todayMb(c: Context): Long {
        val total = rawTodayBytes(c)
        if (total < 0) return -1L
        val p = Store.prefs(c)
        val day = dayKey()
        var attributed = p.getLong("attr", 0L)
        var last = p.getLong("last", 0L)
        if (p.getString("attrDay", "") != day) {
            attributed = 0L
            last = 0L
        }
        var delta = total - last
        if (delta < 0) delta = total
        val chosen = Store.simId(c)
        if (chosen == -1 || Sims.dataSimId() == chosen) attributed += delta
        p.edit().putLong("attr", attributed).putLong("last", total).putString("attrDay", day).apply()
        return attributed / (1024L * 1024L)
    }

    fun dayKey(): String {
        val c = Calendar.getInstance()
        return "${c.get(Calendar.YEAR)}-${c.get(Calendar.DAY_OF_YEAR)}"
    }

    fun fmt(mb: Long): String {
        val v = if (mb < 0) 0 else mb
        return if (v >= 1024) String.format("%.2f GB", v / 1024.0) else "$v MB"
    }
}

data class Sim(val id: Int, val name: String)

object Sims {
    fun hasPermission(c: Context): Boolean =
        c.checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED

    fun list(c: Context): List<Sim> {
        if (!hasPermission(c)) return emptyList()
        return try {
            val sm = c.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE) as SubscriptionManager
            (sm.activeSubscriptionInfoList ?: emptyList()).map {
                val carrier = it.carrierName?.toString().orEmpty().ifBlank { "SIM" }
                Sim(it.subscriptionId, "SIM ${it.simSlotIndex + 1} · $carrier")
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun dataSimId(): Int = SubscriptionManager.getDefaultDataSubscriptionId()
}
